# ADAL For Forms

This sample shows how to use Active Directory Authentication Library (ADAL) in Xamarin.Forms applications. This particular sample uses Dependency Service to process Authentication flow in individual platforms.

After making the changes in code, the app should run and authenticate user on iOS, Android and Windows Phone platforms.
